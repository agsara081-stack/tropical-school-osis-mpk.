-- Supabase PostgreSQL schema starter for OSIS & MPK SMAN 1 Sagaranten
-- Review with a trusted adult/school administrator before production.
-- Run only in a new project after reviewing all policies.

create extension if not exists pgcrypto;

create type public.org_role as enum ('admin', 'osis', 'mpk', 'editor');
create type public.attendance_status as enum ('hadir', 'izin', 'sakit', 'alpa');
create type public.publish_state as enum ('draft', 'published', 'archived');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  role public.org_role not null default 'editor',
  organization text not null default 'OSIS',
  bidang_komisi text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.news (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique,
  summary text,
  body text,
  image_url text,
  state public.publish_state not null default 'draft',
  author_id uuid references public.profiles(id),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.agenda (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  location text,
  starts_at timestamptz,
  ends_at timestamptz,
  state public.publish_state not null default 'draft',
  owner_id uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.aspirations (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  message text not null,
  sender_name text,
  sender_class text,
  status text not null default 'baru' check (status in ('baru','ditinjau','diteruskan','selesai')),
  assigned_to uuid references public.profiles(id),
  internal_notes text,
  created_at timestamptz not null default now()
);

create table public.attendance (
  id uuid primary key default gen_random_uuid(),
  member_name text not null,
  organization text not null check (organization in ('OSIS','MPK')),
  bidang_komisi text,
  attendance_date date not null,
  session text not null check (session in ('pagi','sore','kegiatan')),
  status public.attendance_status not null default 'hadir',
  recorded_by uuid references public.profiles(id),
  notes text,
  created_at timestamptz not null default now(),
  unique(member_name, attendance_date, session)
);

create table public.documents (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null,
  storage_path text not null,
  access_scope text not null default 'internal' check (access_scope in ('public','internal','admin')),
  uploaded_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.inventory (
  id uuid primary key default gen_random_uuid(),
  item_name text not null,
  quantity integer not null default 1 check (quantity >= 0),
  condition text not null default 'baik',
  location text,
  notes text,
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

create table public.loan_records (
  id uuid primary key default gen_random_uuid(),
  inventory_id uuid not null references public.inventory(id),
  borrower_name text not null,
  quantity integer not null default 1 check (quantity > 0),
  borrowed_at date not null default current_date,
  due_at date,
  returned_at date,
  status text not null default 'dipinjam' check (status in ('dipinjam','dikembalikan','terlambat')),
  recorded_by uuid references public.profiles(id),
  notes text
);

-- Role helper. User role is set only by a trusted administrator, never by public signup.
create or replace function public.current_org_role()
returns public.org_role
language sql stable security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid() and active = true
$$;

create or replace function public.is_staff()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists(select 1 from public.profiles where id = auth.uid() and active = true)
$$;

alter table public.profiles enable row level security;
alter table public.news enable row level security;
alter table public.agenda enable row level security;
alter table public.aspirations enable row level security;
alter table public.attendance enable row level security;
alter table public.documents enable row level security;
alter table public.inventory enable row level security;
alter table public.loan_records enable row level security;

-- Profiles: staff can see staff directory; each member can read own profile.
create policy "profiles read self or staff" on public.profiles
for select to authenticated using (id = auth.uid() or public.is_staff());
create policy "admin update profiles" on public.profiles
for update to authenticated using (public.current_org_role() = 'admin')
with check (public.current_org_role() = 'admin');

-- Public pages: only published news/agenda readable without login.
create policy "published news public read" on public.news
for select to anon, authenticated using (state = 'published' or public.is_staff());
create policy "staff manage news" on public.news
for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy "published agenda public read" on public.agenda
for select to anon, authenticated using (state = 'published' or public.is_staff());
create policy "staff manage agenda" on public.agenda
for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- Aspirations must not be publicly readable. To submit anonymously from a public website,
-- use a server-side Edge Function with rate limiting and spam protection; do NOT add anon INSERT
-- policy here unless the risks and protections have been reviewed.
create policy "staff read aspirations" on public.aspirations
for select to authenticated using (public.is_staff());
create policy "staff update aspirations" on public.aspirations
for update to authenticated using (public.is_staff()) with check (public.is_staff());
create policy "staff delete aspirations" on public.aspirations
for delete to authenticated using (public.current_org_role() = 'admin');

create policy "staff read attendance" on public.attendance
for select to authenticated using (public.is_staff());
create policy "staff manage attendance" on public.attendance
for all to authenticated using (public.is_staff()) with check (public.is_staff());

create policy "staff read documents metadata" on public.documents
for select to authenticated using (
  public.current_org_role() = 'admin'
  or (public.is_staff() and access_scope in ('internal','public'))
);
create policy "admin or staff insert documents metadata" on public.documents
for insert to authenticated with check (public.is_staff());
create policy "admin manage documents" on public.documents
for update to authenticated using (public.current_org_role() = 'admin')
with check (public.current_org_role() = 'admin');
create policy "admin delete documents" on public.documents
for delete to authenticated using (public.current_org_role() = 'admin');

create policy "staff manage inventory" on public.inventory
for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy "staff manage loan records" on public.loan_records
for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- IMPORTANT:
-- 1. Create Supabase Storage buckets and matching storage policies separately.
-- 2. Restrict role assignment to trusted admins; never accept role from user sign-up form.
-- 3. Review these RLS policies with a knowledgeable administrator before using real student data.
-- 4. Public anonymous aspiration submission should be implemented through a protected server-side endpoint.
