WEBSITE CUSTOM OSIS & MPK SMAN 1 SAGARANTEN
Tema: Tropical School — biru, hijau, cream

FILE
- index.html: website prototipe custom responsif, bisa dibuka langsung di browser.
- supabase_schema.sql: starter skema database PostgreSQL untuk Supabase, dengan tabel dan Row Level Security awal.
- README.txt: petunjuk penggunaan.

COBA SEKARANG
1. Ekstrak file ZIP.
2. Buka index.html di Chrome atau browser lain.
3. Uji menu, tabs dashboard, form aspirasi demo, dan tombol ekspor JSON.
4. Aspirasi demo hanya disimpan di sessionStorage browser saat itu. Tidak dikirim ke internet dan akan hilang ketika sesi browser berakhir.

ARSITEKTUR PRODUKSI YANG DISARANKAN
- Frontend: custom HTML/CSS/JS (bisa ditingkatkan ke React/Next.js).
- Backend/database/auth: Supabase (PostgreSQL + Auth + Storage + Row Level Security).
- Hosting: Vercel, Netlify, atau hosting statis lain untuk frontend.
- Domain: gunakan domain sekolah/organisasi jika telah disetujui.

FITUR DALAM RANCANGAN
Publik: beranda, profil, OSIS/MPK, berita, agenda, formulir aspirasi.
Internal: dashboard, absensi pagi/sore/kegiatan, administrasi, dokumen, inventaris dan peminjaman.
Pada file demo, panel internal hanya UI contoh; belum terhubung ke database dan belum memiliki login sungguhan.

LANGKAH PENGEMBANGAN KE PRODUKSI
1. Buat project Supabase milik sekolah/organisasi dengan izin administrator.
2. Tinjau dan jalankan supabase_schema.sql setelah ditinjau oleh administrator yang paham keamanan database.
3. Aktifkan Supabase Auth; buat akun staf melalui proses terkontrol. Jangan izinkan pendaftar publik memilih role admin/OSIS/MPK.
4. Buat kebijakan Storage yang sesuai untuk file publik vs internal.
5. Bangun halaman login dan integrasi frontend ke Supabase. Jangan pernah menaruh service_role key di frontend.
6. Untuk aspirasi publik anonim, gunakan endpoint server-side/Edge Function dengan validasi, pembatasan spam, dan kebijakan privasi. SQL sengaja tidak memberi izin INSERT anonim secara langsung.
7. Uji akses per role (publik, OSIS, MPK, admin) sebelum memuat data asli.
8. Minta persetujuan sekolah untuk logo, foto siswa, dokumen, dan penggunaan nama institusi.

KEAMANAN & PRIVASI
- Jangan masukkan data siswa sungguhan ke prototipe.
- Absensi, dokumen internal, dan inventaris harus memiliki autentikasi serta pembatasan akses.
- Gunakan akun organisasi yang dapat diserahterimakan secara resmi dan aktifkan pemulihan akun.
- Skema SQL adalah starter, bukan audit keamanan atau sistem yang sudah siap produksi.
